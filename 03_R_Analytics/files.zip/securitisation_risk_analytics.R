# ============================================================================
#  SECURITISATION RISK ASSESSMENT — COMPLETE R ANALYTICS SCRIPT
#  Project  : Auto Loan ABS Pool — ZAAUTO2024-1
#  Author   : Senior Financial Risk Analyst
#  Date     : 2024
#  Purpose  : Complement the Power BI dashboard with reproducible R analytics
#             covering EDA, Statistical Analysis, ML Models, Time-Series
#             Forecasting, and IFRS 9 Risk Metrics.
# ============================================================================

# ============================================================
# SECTION 0 — PACKAGE INSTALLATION & LOADING
# ============================================================
# Install any missing packages before loading
required_pkgs <- c(
  "tidyverse", "dplyr", "ggplot2", "lubridate",
  "caret", "randomForest", "xgboost", "e1071",
  "pROC", "corrplot", "plotly", "DT",
  "rpart", "rpart.plot", "scales", "gridExtra",
  "forecast", "tseries", "knitr", "kableExtra"
)

for (pkg in required_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org")
  }
}

suppressPackageStartupMessages({
  library(tidyverse)
  library(dplyr)
  library(ggplot2)
  library(lubridate)
  library(caret)
  library(randomForest)
  library(xgboost)
  library(e1071)
  library(pROC)
  library(corrplot)
  library(plotly)
  library(DT)
  library(rpart)
  library(rpart.plot)
  library(scales)
  library(gridExtra)
  library(forecast)
  library(tseries)
  library(knitr)
  library(kableExtra)
})

# Set global plot theme
theme_risk <- function() {
  theme_minimal(base_size = 12) +
    theme(
      plot.title    = element_text(face = "bold", size = 14, colour = "#1B2A49"),
      plot.subtitle = element_text(size = 11, colour = "#555555"),
      axis.title    = element_text(face = "bold", colour = "#1B2A49"),
      legend.position = "bottom",
      panel.grid.minor = element_blank(),
      strip.text    = element_text(face = "bold")
    )
}

# Colour palette consistent with banking/risk dashboards
RISK_COLS <- c(
  "Current"    = "#27AE60",
  "1-29 DPD"  = "#F39C12",
  "30-59 DPD" = "#E67E22",
  "60-89 DPD" = "#E74C3C",
  "90-119 DPD"= "#C0392B",
  "120+ DPD"  = "#922B21",
  "Default"   = "#641E16",
  "Repossessed"= "#1C2833"
)

cat("\n========================================\n")
cat("  SECURITISATION RISK ANALYTICS — R\n")
cat("========================================\n\n")


# ============================================================
# SECTION 1 — DATA IMPORT
# ============================================================
cat(">>> [1/7] Importing datasets ...\n")

# Adjust paths to where your files are stored
DATA_DIR <- "."   # Change to actual path if needed

loan_raw    <- read_csv(file.path(DATA_DIR, "auto_loan_securitisation_data.csv"),
                        show_col_types = FALSE)
dpd_raw     <- read_csv(file.path(DATA_DIR, "dpd_snapshot_history.csv"),
                        show_col_types = FALSE)
loss_raw    <- read_csv(file.path(DATA_DIR, "dynamic_loss_monthly.csv"),
                        show_col_types = FALSE)
vintage_raw <- read_csv(file.path(DATA_DIR, "static_pool_vintage_data.csv"),
                        show_col_types = FALSE)

cat(sprintf("  auto_loan_securitisation_data : %d rows × %d cols\n",
            nrow(loan_raw), ncol(loan_raw)))
cat(sprintf("  dpd_snapshot_history          : %d rows × %d cols\n",
            nrow(dpd_raw), ncol(dpd_raw)))
cat(sprintf("  dynamic_loss_monthly          : %d rows × %d cols\n",
            nrow(loss_raw), ncol(loss_raw)))
cat(sprintf("  static_pool_vintage_data      : %d rows × %d cols\n",
            nrow(vintage_raw), ncol(vintage_raw)))


# ============================================================
# SECTION 2 — DATA PREPARATION & FEATURE ENGINEERING
# ============================================================
cat("\n>>> [2/7] Data preparation & feature engineering ...\n")

## 2.1  Loan-level dataset ------------------------------------------------
loan <- loan_raw %>%
  mutate(
    # Date conversions
    OriginationDate = as_date(OriginationDate),
    CutoffDate      = as_date(CutoffDate),
    MaturityDate    = as_date(MaturityDate),
    LastPaymentDate = as_date(LastPaymentDate),

    # Logical / factor conversions
    IsDefaulted  = as.logical(IsDefaulted),
    IsModified   = as.logical(IsModified),
    HasInsurance = as.logical(HasInsurance),
    IsNewVehicle = as.logical(IsNewVehicle),

    IFRS9_Stage        = factor(IFRS9_Stage, levels = 1:3,
                                labels = c("Stage 1", "Stage 2", "Stage 3")),
    DelinquencyStatus  = factor(DelinquencyStatus,
                                levels = c("Current","1-29 DPD","30-59 DPD",
                                           "60-89 DPD","90-119 DPD",
                                           "120+ DPD","Default","Repossessed")),
    LoanPurpose        = factor(LoanPurpose),
    VehicleType        = factor(VehicleType),
    Region             = factor(Region),
    EmploymentType     = factor(EmploymentType),
    InsuranceType      = factor(InsuranceType),
    OriginationChannel = factor(OriginationChannel),

    # Feature engineering
    VehicleAge          = as.integer(format(CutoffDate, "%Y")) - VehicleYear,
    Depreciation_Pct    = 1 - (CurrentVehicleValue / OriginalVehicleValue),
    PaymentEfficiency   = TotalPaymentsMade / pmax(TotalPaymentsDue, 1),
    DelinquencyBucket   = case_when(
      DelinquencyDays == 0              ~ "Current",
      DelinquencyDays <= 29             ~ "1-29 DPD",
      DelinquencyDays <= 59             ~ "30-59 DPD",
      DelinquencyDays <= 89             ~ "60-89 DPD",
      DelinquencyDays <= 119            ~ "90-119 DPD",
      DelinquencyDays <= 150            ~ "120+ DPD",
      IsDefaulted                       ~ "Default",
      TRUE                              ~ "Repossessed"
    ),
    DelinquencyBucket = factor(DelinquencyBucket,
                               levels = c("Current","1-29 DPD","30-59 DPD",
                                          "60-89 DPD","90-119 DPD",
                                          "120+ DPD","Default","Repossessed")),
    # Recovery rate per loan
    Recovery_Rate = if_else(LossAmount > 0,
                            RecoveryAmount / pmax(LossAmount, 1), 0),
    # Collateral coverage ratio
    CollateralCoverage = CurrentVehicleValue / pmax(CurrentBalance, 1),
    # Income-to-loan ratio
    Income_To_Loan = AnnualIncome_INR / pmax(OriginalLoanAmount, 1),
    # Payment-to-income (PTI)
    PTI_Ratio = MonthlyEMI / pmax(AnnualIncome_INR / 12, 1)
  )

# Outlier capping using IQR method on key numeric columns
cap_outliers <- function(x, mult = 3) {
  qnt <- quantile(x, probs = c(.25, .75), na.rm = TRUE)
  iqr <- IQR(x, na.rm = TRUE)
  pmin(pmax(x, qnt[1] - mult * iqr), qnt[2] + mult * iqr)
}

loan <- loan %>%
  mutate(
    AnnualIncome_INR_cap = cap_outliers(AnnualIncome_INR),
    OriginalLoanAmount_cap = cap_outliers(OriginalLoanAmount),
    ECL_Provision_cap    = cap_outliers(ECL_Provision)
  )

## 2.2  DPD snapshot dataset ----------------------------------------------
dpd <- dpd_raw %>%
  mutate(
    SnapshotDate    = as_date(SnapshotDate),
    LastPaymentDate = as_date(LastPaymentDate),
    CureFlag        = as.logical(CureFlag),
    RepossessionFlag= as.logical(RepossessionFlag),
    WriteOffFlag    = as.logical(WriteOffFlag),
    DPD_Bucket      = factor(DPD_Bucket,
                             levels = c("Current","1-29 DPD","30-59 DPD",
                                        "60-89 DPD","90-119 DPD",
                                        "120+ DPD","Default","Repossessed")),
    DPD_Bucket_Prior = factor(DPD_Bucket_Prior,
                              levels = c("Current","1-29 DPD","30-59 DPD",
                                         "60-89 DPD","90-119 DPD",
                                         "120+ DPD","Default","Repossessed"))
  )

## 2.3  Monthly loss dataset ----------------------------------------------
loss <- loss_raw %>%
  mutate(
    ReportingDate = as_date(ReportingDate),
    GrossLossRate = GrossLoss_ThisMonth / pmax(BOP_Balance, 1),
    RecoveryRate  = Recoveries_ThisMonth / pmax(GrossLoss_ThisMonth, 1)
  )

## 2.4  Vintage dataset ---------------------------------------------------
vintage <- vintage_raw %>%
  mutate(VintageStartDate = as_date(VintageStartDate))

cat("  Data preparation complete.\n")
cat(sprintf("  Loan dataset: %d features after engineering.\n", ncol(loan)))


# ============================================================
# SECTION 3 — STATISTICAL ANALYSIS (Portfolio KPIs)
# ============================================================
cat("\n>>> [3/7] Computing portfolio statistics ...\n")

## 3.1  Pool-level summary
total_loans          <- nrow(loan)
total_original_bal   <- sum(loan$OriginalLoanAmount, na.rm = TRUE)
total_current_bal    <- sum(loan$CurrentBalance, na.rm = TRUE)
pool_factor          <- total_current_bal / total_original_bal
defaulted_count      <- sum(loan$IsDefaulted, na.rm = TRUE)
default_rate         <- defaulted_count / total_loans
wtd_avg_rate         <- weighted.mean(loan$InterestRate,
                                      w = loan$CurrentBalance, na.rm = TRUE)
total_ecl            <- sum(loan$ECL_Provision, na.rm = TRUE)
ecl_to_balance       <- total_ecl / total_current_bal
total_gross_loss     <- sum(loss$GrossLoss_ThisMonth, na.rm = TRUE)
total_recoveries     <- sum(loss$Recoveries_ThisMonth, na.rm = TRUE)
recovery_rate_pool   <- total_recoveries / pmax(total_gross_loss, 1)
total_net_loss       <- sum(loss$NetLoss_ThisMonth, na.rm = TRUE)
loss_rate            <- total_net_loss / total_original_bal
avg_cpr              <- mean(loss$CPR_Annualised, na.rm = TRUE)
avg_coll_eff         <- mean(loss$CollectionEfficiency, na.rm = TRUE)

# Delinquency ratios
delinq_30plus_bal  <- sum(loan$CurrentBalance[loan$DelinquencyDays >= 30],  na.rm = TRUE)
delinq_60plus_bal  <- sum(loan$CurrentBalance[loan$DelinquencyDays >= 60],  na.rm = TRUE)
delinq_90plus_bal  <- sum(loan$CurrentBalance[loan$DelinquencyDays >= 90],  na.rm = TRUE)
delinq_30plus_rate <- delinq_30plus_bal / total_current_bal
delinq_60plus_rate <- delinq_60plus_bal / total_current_bal
delinq_90plus_rate <- delinq_90plus_bal / total_current_bal

# PD / LGD / EAD / ECL aggregates
avg_pd  <- mean(loan$PD_Estimate,  na.rm = TRUE)
avg_lgd <- mean(loan$LGD_Estimate, na.rm = TRUE)
avg_ead <- mean(loan$EAD,          na.rm = TRUE)

portfolio_kpis <- tibble(
  KPI   = c("Total Loans","Original Pool Balance (INR Cr)",
            "Current Pool Balance (INR Cr)","Pool Factor",
            "Defaulted Loans","Default Rate (%)",
            "WA Interest Rate (%)","Total ECL Provision (INR Cr)",
            "ECL / Current Balance (%)","Recovery Rate (%)",
            "Net Loss Rate (%)","Avg CPR (Annualised %)",
            "Avg Collection Efficiency (%)","30+ DPD Rate (%)",
            "60+ DPD Rate (%)","90+ DPD Rate (%)",
            "Avg PD (%)","Avg LGD (%)","Avg EAD (INR)"),
  Value = c(
    total_loans,
    round(total_original_bal / 1e7, 2),
    round(total_current_bal  / 1e7, 2),
    round(pool_factor, 4),
    defaulted_count,
    round(default_rate * 100, 2),
    round(wtd_avg_rate, 2),
    round(total_ecl / 1e7, 2),
    round(ecl_to_balance * 100, 2),
    round(recovery_rate_pool * 100, 2),
    round(loss_rate * 100, 4),
    round(avg_cpr * 100, 2),
    round(avg_coll_eff * 100, 2),
    round(delinq_30plus_rate * 100, 2),
    round(delinq_60plus_rate * 100, 2),
    round(delinq_90plus_rate * 100, 2),
    round(avg_pd * 100, 2),
    round(avg_lgd * 100, 2),
    round(avg_ead, 0)
  )
)

print(portfolio_kpis, n = Inf)


# ============================================================
# SECTION 4 — EXPLORATORY DATA ANALYSIS (EDA)
# ============================================================
cat("\n>>> [4/7] Generating EDA visualisations ...\n")

dir.create("plots", showWarnings = FALSE)

## --- 4.1  Loan Purpose Distribution ---
p_purpose <- loan %>%
  count(LoanPurpose) %>%
  mutate(pct = n / sum(n)) %>%
  ggplot(aes(x = reorder(LoanPurpose, -pct), y = pct, fill = LoanPurpose)) +
  geom_col(width = 0.6, show.legend = FALSE) +
  geom_text(aes(label = scales::percent(pct, accuracy = 0.1)),
            vjust = -0.4, fontface = "bold") +
  scale_y_continuous(labels = percent_format()) +
  scale_fill_brewer(palette = "Set2") +
  labs(title = "Loan Purpose Distribution",
       subtitle = "% share of the securitisation pool",
       x = NULL, y = "Portfolio Share") +
  theme_risk()
ggsave("plots/01_loan_purpose.png", p_purpose, width = 7, height = 5, dpi = 150)

## --- 4.2  Vehicle Type Distribution ---
p_vtype <- loan %>%
  count(VehicleType) %>%
  mutate(pct = n / sum(n)) %>%
  ggplot(aes(x = reorder(VehicleType, -pct), y = pct, fill = VehicleType)) +
  geom_col(width = 0.6, show.legend = FALSE) +
  geom_text(aes(label = scales::percent(pct, accuracy = 0.1)),
            vjust = -0.4, fontface = "bold") +
  scale_y_continuous(labels = percent_format()) +
  scale_fill_brewer(palette = "Paired") +
  labs(title = "Vehicle Type Distribution",
       subtitle = "Collateral composition of the ABS pool",
       x = NULL, y = "Portfolio Share") +
  theme_risk()
ggsave("plots/02_vehicle_type.png", p_vtype, width = 7, height = 5, dpi = 150)

## --- 4.3  Region-wise Portfolio Exposure ---
p_region <- loan %>%
  group_by(Region) %>%
  summarise(Balance_Cr = sum(CurrentBalance, na.rm = TRUE) / 1e7,
            Loans = n(), .groups = "drop") %>%
  ggplot(aes(x = reorder(Region, -Balance_Cr), y = Balance_Cr, fill = Region)) +
  geom_col(width = 0.6, show.legend = FALSE) +
  geom_text(aes(label = paste0("₹", round(Balance_Cr, 1), " Cr")),
            vjust = -0.4, fontface = "bold") +
  scale_fill_brewer(palette = "Dark2") +
  labs(title = "Region-wise Portfolio Exposure",
       subtitle = "Current outstanding balance (INR Crore)",
       x = NULL, y = "Outstanding Balance (₹ Crore)") +
  theme_risk()
ggsave("plots/03_region_exposure.png", p_region, width = 7, height = 5, dpi = 150)

## --- 4.4  DPD Bucket Distribution ---
p_dpd <- loan %>%
  count(DelinquencyBucket) %>%
  mutate(pct = n / sum(n)) %>%
  ggplot(aes(x = DelinquencyBucket, y = pct,
             fill = DelinquencyBucket)) +
  geom_col(width = 0.7, show.legend = FALSE) +
  geom_text(aes(label = scales::percent(pct, accuracy = 0.1)),
            vjust = -0.4, size = 3.5) +
  scale_fill_manual(values = RISK_COLS) +
  scale_y_continuous(labels = percent_format()) +
  labs(title = "Days Past Due (DPD) Bucket Distribution",
       subtitle = "Delinquency segmentation of the loan pool",
       x = "DPD Bucket", y = "% of Pool") +
  theme_risk() +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))
ggsave("plots/04_dpd_distribution.png", p_dpd, width = 8, height = 5, dpi = 150)

## --- 4.5  Vintage Analysis — Cumulative Net Loss Rate ---
p_vintage <- vintage %>%
  ggplot(aes(x = MonthsOnBook, y = CumulativeNetLossRate * 100,
             colour = VintageID, group = VintageID)) +
  geom_line(linewidth = 0.8) +
  scale_color_brewer(palette = "Spectral") +
  labs(title = "Vintage Analysis — Cumulative Net Loss Rate",
       subtitle = "Performance curves by origination vintage",
       x = "Months on Book", y = "Cumulative Net Loss Rate (%)",
       colour = "Vintage") +
  theme_risk()
ggsave("plots/05_vintage_analysis.png", p_vintage, width = 9, height = 6, dpi = 150)

## --- 4.6  Monthly Loss Trends ---
p_loss_trend <- loss %>%
  select(ReportingDate, GrossLoss_ThisMonth, Recoveries_ThisMonth,
         NetLoss_ThisMonth) %>%
  pivot_longer(-ReportingDate, names_to = "Metric", values_to = "Amount") %>%
  mutate(Metric = recode(Metric,
                         "GrossLoss_ThisMonth"    = "Gross Loss",
                         "Recoveries_ThisMonth"   = "Recoveries",
                         "NetLoss_ThisMonth"      = "Net Loss"),
         Amount_Lac = Amount / 1e5) %>%
  ggplot(aes(x = ReportingDate, y = Amount_Lac, colour = Metric, group = Metric)) +
  geom_line(linewidth = 1.1) +
  geom_point(size = 2.5) +
  scale_color_manual(values = c("Gross Loss" = "#E74C3C",
                                "Recoveries" = "#27AE60",
                                "Net Loss"   = "#2980B9")) +
  scale_x_date(date_labels = "%b-%y", date_breaks = "1 month") +
  labs(title = "Monthly Loss & Recovery Trends",
       subtitle = "Gross Loss, Recoveries and Net Loss (INR Lakh)",
       x = NULL, y = "Amount (₹ Lakh)", colour = NULL) +
  theme_risk() +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
ggsave("plots/06_monthly_loss_trend.png", p_loss_trend, width = 10, height = 5, dpi = 150)

## --- 4.7  Collection Efficiency Trend ---
p_coll <- loss %>%
  ggplot(aes(x = ReportingDate, y = CollectionEfficiency)) +
  geom_line(colour = "#2980B9", linewidth = 1.1) +
  geom_point(colour = "#1B2A49", size = 2.5) +
  geom_hline(yintercept = 1, linetype = "dashed", colour = "#E74C3C") +
  scale_x_date(date_labels = "%b-%y", date_breaks = "1 month") +
  labs(title = "Monthly Collection Efficiency",
       subtitle = "Ratio of Collections to Billing (>1 = over-collection)",
       x = NULL, y = "Collection Efficiency Ratio") +
  theme_risk() +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
ggsave("plots/07_collection_efficiency.png", p_coll, width = 9, height = 5, dpi = 150)

## --- 4.8  Correlation Heatmap ---
numeric_cols <- loan %>%
  select(InterestRate, LTV_AtOrigination, LTV_Current, BorrowerAge,
         DTI_Ratio, CIBIL_Score_Origination, CIBIL_Score_Current,
         PD_Estimate, LGD_Estimate, ECL_Provision,
         DelinquencyDays, PaymentEfficiency, VehicleAge,
         Depreciation_Pct, PTI_Ratio) %>%
  na.omit()

cor_mat <- cor(numeric_cols)

png("plots/08_correlation_heatmap.png", width = 900, height = 900, res = 120)
corrplot(cor_mat,
         method = "color", type = "upper", order = "hclust",
         tl.cex = 0.75, tl.col = "#1B2A49",
         col = colorRampPalette(c("#2980B9","white","#E74C3C"))(200),
         addCoef.col = "black", number.cex = 0.55,
         title = "Correlation Heatmap — Key Risk Variables",
         mar = c(0,0,2,0))
dev.off()

## --- 4.9  CIBIL Score Distribution (Histogram) ---
p_cibil <- ggplot(loan, aes(x = CIBIL_Score_Current, fill = IFRS9_Stage)) +
  geom_histogram(binwidth = 20, colour = "white", alpha = 0.85) +
  scale_fill_manual(values = c("Stage 1"="#27AE60","Stage 2"="#F39C12","Stage 3"="#E74C3C")) +
  labs(title = "CIBIL Score Distribution by IFRS 9 Stage",
       subtitle = "Current credit score segmented by impairment stage",
       x = "CIBIL Score (Current)", y = "Number of Loans",
       fill = "IFRS 9 Stage") +
  theme_risk()
ggsave("plots/09_cibil_histogram.png", p_cibil, width = 8, height = 5, dpi = 150)

## --- 4.10  Boxplot — ECL Provision by IFRS 9 Stage ---
p_ecl_box <- ggplot(loan, aes(x = IFRS9_Stage, y = ECL_Provision / 1e5,
                               fill = IFRS9_Stage)) +
  geom_boxplot(outlier.colour = "#E74C3C", outlier.size = 1.5, alpha = 0.8) +
  scale_fill_manual(values = c("Stage 1"="#27AE60","Stage 2"="#F39C12",
                                "Stage 3"="#E74C3C")) +
  scale_y_continuous(labels = comma_format()) +
  labs(title = "ECL Provision Distribution by IFRS 9 Stage",
       subtitle = "Boxplot showing spread and outliers (₹ Lakh)",
       x = "IFRS 9 Stage", y = "ECL Provision (₹ Lakh)",
       fill = NULL) +
  theme_risk()
ggsave("plots/10_ecl_boxplot.png", p_ecl_box, width = 7, height = 5, dpi = 150)

## --- 4.11  Scatter: LTV vs PD coloured by Stage ---
p_scatter <- loan %>%
  sample_n(min(400, nrow(loan))) %>%
  ggplot(aes(x = LTV_Current, y = PD_Estimate * 100,
             colour = IFRS9_Stage, size = CurrentBalance / 1e5)) +
  geom_point(alpha = 0.65) +
  scale_colour_manual(values = c("Stage 1"="#27AE60","Stage 2"="#F39C12",
                                  "Stage 3"="#E74C3C")) +
  scale_size_continuous(range = c(1, 5), guide = "none") +
  labs(title = "Current LTV vs Probability of Default",
       subtitle = "Bubble size = Current Balance; coloured by IFRS 9 Stage",
       x = "LTV (Current)", y = "PD Estimate (%)",
       colour = "IFRS 9 Stage") +
  theme_risk()
ggsave("plots/11_ltv_vs_pd_scatter.png", p_scatter, width = 8, height = 6, dpi = 150)

## --- 4.12  Pool Factor over Months ---
p_pool_factor <- vintage %>%
  group_by(MonthsOnBook) %>%
  summarise(Avg_PoolFactor = mean(PoolFactor, na.rm = TRUE), .groups = "drop") %>%
  ggplot(aes(x = MonthsOnBook, y = Avg_PoolFactor)) +
  geom_area(fill = "#AED6F1", alpha = 0.5) +
  geom_line(colour = "#1B2A49", linewidth = 1.1) +
  scale_y_continuous(labels = percent_format()) +
  labs(title = "Average Pool Factor by Months on Book",
       subtitle = "Amortisation trajectory across all vintages",
       x = "Months on Book", y = "Pool Factor") +
  theme_risk()
ggsave("plots/12_pool_factor.png", p_pool_factor, width = 8, height = 5, dpi = 150)

cat("  All EDA plots saved in ./plots/\n")


# ============================================================
# SECTION 5 — MACHINE LEARNING MODELS
# ============================================================
cat("\n>>> [5/7] Training ML models ...\n")

# Prepare a modelling dataset (select key predictors)
model_data <- loan %>%
  select(
    LTV_AtOrigination, LTV_Current, InterestRate, DTI_Ratio,
    CIBIL_Score_Origination, CIBIL_Score_Current, BorrowerAge,
    MonthsOnBook, RemainingTerm, DelinquencyDays,
    Times30DPD_Last12M, Times60DPD_Last12M, Times90DPD_Last12M,
    PaymentEfficiency, VehicleAge, Depreciation_Pct, PTI_Ratio,
    PD_Estimate, LGD_Estimate,
    IsDefaulted, IFRS9_Stage, DelinquencyBucket
  ) %>%
  mutate(
    IsDefaulted_bin   = as.integer(IsDefaulted),
    IFRS9_Stage_num   = as.integer(IFRS9_Stage),
    DelinqBucket_num  = as.integer(DelinquencyBucket)
  ) %>%
  na.omit()

set.seed(42)
train_idx <- createDataPartition(model_data$IsDefaulted_bin, p = 0.75, list = FALSE)
train     <- model_data[train_idx,  ]
test      <- model_data[-train_idx, ]

cat(sprintf("  Train: %d rows | Test: %d rows\n", nrow(train), nrow(test)))

# Helper to print and return classification metrics
eval_clf <- function(actual, predicted, prob = NULL, model_name = "") {
  cm   <- confusionMatrix(factor(predicted, levels = c(0,1)),
                          factor(actual,    levels = c(0,1)),
                          positive = "1")
  acc  <- cm$overall["Accuracy"]
  prec <- cm$byClass["Precision"]
  rec  <- cm$byClass["Recall"]
  f1   <- cm$byClass["F1"]

  auc_val <- NA
  if (!is.null(prob)) {
    roc_obj <- roc(actual, prob, quiet = TRUE)
    auc_val <- auc(roc_obj)
  }

  cat(sprintf("\n  [%s]\n  Accuracy: %.4f | Precision: %.4f | Recall: %.4f | F1: %.4f | AUC: %.4f\n",
              model_name, acc, ifelse(is.na(prec),0,prec),
              ifelse(is.na(rec),0,rec), ifelse(is.na(f1),0,f1),
              ifelse(is.na(auc_val),0,auc_val)))
  list(cm = cm, acc = acc, prec = prec, rec = rec, f1 = f1, auc = auc_val)
}

# ---- MODEL 1 : Logistic Regression — Predict Default ----------------
cat("\n  --- Model 1: Logistic Regression (Default Prediction) ---\n")

lr_features <- c("LTV_Current","InterestRate","DTI_Ratio",
                 "CIBIL_Score_Current","DelinquencyDays",
                 "Times90DPD_Last12M","PaymentEfficiency",
                 "Depreciation_Pct","PTI_Ratio")

lr_formula <- as.formula(
  paste("IsDefaulted_bin ~", paste(lr_features, collapse = " + "))
)

lr_model <- glm(lr_formula, data = train, family = binomial(link = "logit"))
lr_prob  <- predict(lr_model, test, type = "response")
lr_pred  <- as.integer(lr_prob > 0.5)
lr_res   <- eval_clf(test$IsDefaulted_bin, lr_pred, lr_prob, "Logistic Regression")

# ROC curve
roc_lr <- roc(test$IsDefaulted_bin, lr_prob, quiet = TRUE)
png("plots/ML_01_ROC_LogisticReg.png", width = 600, height = 500, res = 100)
plot(roc_lr, col = "#2980B9", lwd = 2,
     main = paste("ROC — Logistic Regression | AUC =",
                  round(auc(roc_lr), 3)))
dev.off()

# ---- MODEL 2 : Random Forest — Predict IFRS 9 Stage ----------------
cat("\n  --- Model 2: Random Forest (IFRS 9 Stage Prediction) ---\n")

rf_features <- c("LTV_Current","InterestRate","DTI_Ratio",
                 "CIBIL_Score_Current","DelinquencyDays",
                 "Times30DPD_Last12M","Times60DPD_Last12M","Times90DPD_Last12M",
                 "PaymentEfficiency","VehicleAge","Depreciation_Pct",
                 "MonthsOnBook","PD_Estimate","LGD_Estimate")

rf_train <- train %>%
  select(all_of(rf_features), IFRS9_Stage_num) %>%
  mutate(IFRS9_Stage_num = factor(IFRS9_Stage_num))
rf_test  <- test %>%
  select(all_of(rf_features), IFRS9_Stage_num) %>%
  mutate(IFRS9_Stage_num = factor(IFRS9_Stage_num))

set.seed(42)
rf_model <- randomForest(
  IFRS9_Stage_num ~ .,
  data       = rf_train,
  ntree      = 300,
  mtry       = 4,
  importance = TRUE
)

rf_pred_class <- predict(rf_model, rf_test)
rf_acc        <- mean(rf_pred_class == rf_test$IFRS9_Stage_num)
cat(sprintf("\n  [Random Forest — IFRS9 Stage]\n  Accuracy: %.4f\n", rf_acc))

# Feature importance plot
rf_imp <- importance(rf_model) %>%
  as.data.frame() %>%
  rownames_to_column("Feature") %>%
  arrange(desc(MeanDecreaseGini))

p_rf_imp <- rf_imp %>%
  head(12) %>%
  ggplot(aes(x = reorder(Feature, MeanDecreaseGini),
             y = MeanDecreaseGini, fill = MeanDecreaseGini)) +
  geom_col(show.legend = FALSE) +
  coord_flip() +
  scale_fill_gradient(low = "#AED6F1", high = "#1B2A49") +
  labs(title = "Random Forest — Feature Importance",
       subtitle = "IFRS 9 Stage prediction (Mean Decrease Gini)",
       x = NULL, y = "Mean Decrease Gini") +
  theme_risk()
ggsave("plots/ML_02_RF_FeatureImportance.png", p_rf_imp, width = 8, height = 6, dpi = 150)

# Confusion matrix heatmap
rf_cm_tbl <- as.data.frame(table(Predicted = rf_pred_class,
                                  Actual    = rf_test$IFRS9_Stage_num))
p_rf_cm <- ggplot(rf_cm_tbl, aes(Actual, Predicted, fill = Freq)) +
  geom_tile(colour = "white") +
  geom_text(aes(label = Freq), fontface = "bold", size = 5) +
  scale_fill_gradient(low = "#EBF5FB", high = "#1B2A49") +
  labs(title = "Confusion Matrix — Random Forest (IFRS 9 Stage)",
       x = "Actual Stage", y = "Predicted Stage") +
  theme_risk()
ggsave("plots/ML_02b_RF_ConfusionMatrix.png", p_rf_cm, width = 6, height = 5, dpi = 150)

# ---- MODEL 3 : XGBoost — Predict ECL (regression) ----------------
cat("\n  --- Model 3: XGBoost (ECL Prediction — Regression) ---\n")

xgb_features <- c("LTV_Current","InterestRate","DTI_Ratio",
                   "CIBIL_Score_Current","DelinquencyDays",
                   "Times90DPD_Last12M","PaymentEfficiency",
                   "PD_Estimate","LGD_Estimate","MonthsOnBook",
                   "Depreciation_Pct","PTI_Ratio")

xgb_train_mat <- xgb.DMatrix(
  data  = as.matrix(train[, xgb_features]),
  label = train$PD_Estimate   # using PD as proxy for ECL rank
)
xgb_test_mat <- xgb.DMatrix(
  data  = as.matrix(test[, xgb_features]),
  label = test$PD_Estimate
)

xgb_params <- list(
  objective        = "reg:squarederror",
  eta              = 0.05,
  max_depth        = 5,
  subsample        = 0.8,
  colsample_bytree = 0.8,
  min_child_weight = 3
)

set.seed(42)
xgb_model <- xgb.train(
  params  = xgb_params,
  data    = xgb_train_mat,
  nrounds = 200,
  verbose = 0,
  watchlist = list(train = xgb_train_mat, test = xgb_test_mat),
  early_stopping_rounds = 20,
  print_every_n = 50
)

xgb_pred <- predict(xgb_model, xgb_test_mat)
xgb_rmse <- sqrt(mean((xgb_pred - test$PD_Estimate)^2))
xgb_r2   <- cor(xgb_pred, test$PD_Estimate)^2
cat(sprintf("\n  [XGBoost — PD/ECL Regression]\n  RMSE: %.6f | R²: %.4f\n",
            xgb_rmse, xgb_r2))

# Feature importance
xgb_imp <- xgb.importance(feature_names = xgb_features, model = xgb_model)
p_xgb_imp <- xgb_imp %>%
  head(12) %>%
  ggplot(aes(x = reorder(Feature, Gain), y = Gain, fill = Gain)) +
  geom_col(show.legend = FALSE) +
  coord_flip() +
  scale_fill_gradient(low = "#FAD7A0", high = "#E67E22") +
  labs(title = "XGBoost — Feature Importance (Gain)",
       subtitle = "Drivers of PD / ECL prediction",
       x = NULL, y = "Information Gain") +
  theme_risk()
ggsave("plots/ML_03_XGB_FeatureImportance.png", p_xgb_imp, width = 8, height = 6, dpi = 150)

# Actual vs Predicted scatter
xgb_res_df <- tibble(Actual = test$PD_Estimate, Predicted = xgb_pred)
p_xgb_fit  <- ggplot(xgb_res_df, aes(x = Actual, y = Predicted)) +
  geom_point(alpha = 0.5, colour = "#E67E22") +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", colour = "#1B2A49") +
  labs(title = "XGBoost — Actual vs Predicted PD",
       subtitle = paste0("R² = ", round(xgb_r2, 4)),
       x = "Actual PD", y = "Predicted PD") +
  theme_risk()
ggsave("plots/ML_03b_XGB_ActualVsPredicted.png", p_xgb_fit,
       width = 7, height = 6, dpi = 150)

# ---- MODEL 4 : Decision Tree — Predict Delinquency Bucket ----------
cat("\n  --- Model 4: Decision Tree (Delinquency Bucket) ---\n")

dt_features <- c("LTV_Current","InterestRate","DTI_Ratio",
                  "CIBIL_Score_Current","Times30DPD_Last12M",
                  "Times60DPD_Last12M","Times90DPD_Last12M",
                  "PaymentEfficiency","MonthsOnBook","PTI_Ratio")

# Simplify to 3-level target: Current / Early Delinquency / Severe
dt_data <- model_data %>%
  mutate(
    DelinqSimple = case_when(
      DelinquencyDays == 0     ~ "Current",
      DelinquencyDays <= 59    ~ "Early_DPD",
      TRUE                     ~ "Severe_DPD"
    ) %>% factor()
  )

dt_train <- dt_data[train_idx,  c(dt_features, "DelinqSimple")]
dt_test  <- dt_data[-train_idx, c(dt_features, "DelinqSimple")]

dt_model <- rpart(
  DelinqSimple ~ .,
  data    = dt_train,
  method  = "class",
  control = rpart.control(cp = 0.005, maxdepth = 6, minsplit = 10)
)

dt_pred <- predict(dt_model, dt_test, type = "class")
dt_cm   <- confusionMatrix(dt_pred, dt_test$DelinqSimple)
dt_acc  <- dt_cm$overall["Accuracy"]
cat(sprintf("\n  [Decision Tree — Delinquency Bucket]\n  Accuracy: %.4f\n", dt_acc))

png("plots/ML_04_DecisionTree.png", width = 1200, height = 700, res = 100)
rpart.plot(dt_model, type = 4, extra = 104,
           main = "Decision Tree — Delinquency Bucket Prediction",
           cex = 0.65)
dev.off()

# Confusion matrix heatmap
dt_cm_df <- as.data.frame(dt_cm$table)
p_dt_cm  <- ggplot(dt_cm_df, aes(Reference, Prediction, fill = Freq)) +
  geom_tile(colour = "white") +
  geom_text(aes(label = Freq), fontface = "bold", size = 5) +
  scale_fill_gradient(low = "#FDFEFE", high = "#1B4F72") +
  labs(title = "Confusion Matrix — Decision Tree (Delinquency)",
       x = "Actual", y = "Predicted") +
  theme_risk()
ggsave("plots/ML_04b_DT_ConfusionMatrix.png", p_dt_cm,
       width = 6, height = 5, dpi = 150)

## ---- Model Comparison Summary Table -----------------------------------
model_comparison <- tibble(
  Model     = c("Logistic Regression","Random Forest","XGBoost (Reg)","Decision Tree"),
  Target    = c("Default (Binary)","IFRS9 Stage","PD / ECL","Delinquency Bucket"),
  Algorithm = c("GLM Binomial","Random Forest","XGBoost","CART"),
  Metric    = c(
    paste0("Accuracy: ", round(lr_res$acc, 4)),
    paste0("Accuracy: ", round(rf_acc, 4)),
    paste0("R²: ", round(xgb_r2, 4),", RMSE: ", round(xgb_rmse, 6)),
    paste0("Accuracy: ", round(dt_acc, 4))
  ),
  AUC_F1 = c(
    paste0("AUC: ", round(auc(roc_lr), 4)),
    "—",
    "—",
    paste0("F1 (macro): ", round(mean(dt_cm$byClass[,"F1"], na.rm=TRUE), 4))
  )
)
cat("\n\n  ---- MODEL COMPARISON ----\n")
print(model_comparison)


# ============================================================
# SECTION 6 — TIME SERIES FORECASTING
# ============================================================
cat("\n>>> [6/7] Time series forecasting ...\n")

## 6.1  Net Loss Forecasting (ARIMA)
loss_ts <- ts(loss$NetLoss_ThisMonth, frequency = 12,
              start = c(year(min(loss$ReportingDate)),
                        month(min(loss$ReportingDate))))

adf_result <- adf.test(loss_ts)
cat(sprintf("  ADF test p-value: %.4f (%s)\n",
            adf_result$p.value,
            ifelse(adf_result$p.value < 0.05, "Stationary","Non-stationary")))

arima_fit   <- auto.arima(loss_ts, seasonal = FALSE, stepwise = FALSE, ic = "aic")
arima_fcst  <- forecast(arima_fit, h = 6)

png("plots/TS_01_NetLoss_Forecast.png", width = 800, height = 500, res = 100)
plot(arima_fcst,
     main = "Monthly Net Loss Forecast (ARIMA) — Next 6 Months",
     xlab = "Time", ylab = "Net Loss (INR)",
     col  = "#E74C3C", fcol = "#F39C12", shadecols = c("#FAD7A0","#FDEBD0"))
dev.off()

## 6.2  Collection Efficiency Trend (ETS)
coll_ts  <- ts(loss$CollectionEfficiency, frequency = 12,
               start = c(year(min(loss$ReportingDate)),
                         month(min(loss$ReportingDate))))
ets_fit  <- ets(coll_ts)
ets_fcst <- forecast(ets_fit, h = 6)

png("plots/TS_02_CollectionEff_Forecast.png", width = 800, height = 500, res = 100)
plot(ets_fcst,
     main = "Collection Efficiency Forecast (ETS) — Next 6 Months",
     xlab = "Time", ylab = "Collection Efficiency Ratio",
     col  = "#2980B9", fcol = "#27AE60", shadecols = c("#A9DFBF","#D5F5E3"))
dev.off()

## 6.3  CPR Trend
cpr_ts  <- ts(loss$CPR_Annualised, frequency = 12,
              start = c(year(min(loss$ReportingDate)),
                        month(min(loss$ReportingDate))))
cpr_fcst <- forecast(auto.arima(cpr_ts), h = 6)

png("plots/TS_03_CPR_Forecast.png", width = 800, height = 500, res = 100)
plot(cpr_fcst,
     main = "Annualised CPR Forecast — Next 6 Months",
     xlab = "Time", ylab = "CPR (Annualised)",
     col  = "#8E44AD", fcol = "#9B59B6", shadecols = c("#D7BDE2","#F5EEF8"))
dev.off()

cat("  Time-series forecasts saved.\n")


# ============================================================
# SECTION 7 — RISK ANALYTICS (IFRS 9 & Credit Risk)
# ============================================================
cat("\n>>> [7/7] Risk analytics computations ...\n")

## 7.1  PD / LGD / EAD / ECL by IFRS 9 Stage
ifrs9_summary <- loan %>%
  group_by(IFRS9_Stage) %>%
  summarise(
    Loans      = n(),
    Bal_Cr     = sum(CurrentBalance, na.rm = TRUE) / 1e7,
    Avg_PD_pct = mean(PD_Estimate,   na.rm = TRUE) * 100,
    Avg_LGD_pct= mean(LGD_Estimate,  na.rm = TRUE) * 100,
    Avg_EAD    = mean(EAD,            na.rm = TRUE),
    Total_ECL_Cr = sum(ECL_Provision, na.rm = TRUE) / 1e7,
    ECL_Coverage = sum(ECL_Provision, na.rm = TRUE) /
                   sum(CurrentBalance, na.rm = TRUE) * 100,
    .groups = "drop"
  )
cat("\n  IFRS 9 Stage Summary:\n")
print(ifrs9_summary)

## 7.2  Stage Migration Matrix (from DPD snapshot)
migration <- dpd %>%
  filter(!is.na(DPD_Bucket), !is.na(DPD_Bucket_Prior)) %>%
  count(From = DPD_Bucket_Prior, To = DPD_Bucket) %>%
  group_by(From) %>%
  mutate(Rate = n / sum(n)) %>%
  ungroup()

p_migration <- migration %>%
  ggplot(aes(x = To, y = From, fill = Rate)) +
  geom_tile(colour = "white", linewidth = 0.5) +
  geom_text(aes(label = scales::percent(Rate, accuracy = 1)),
            size = 3.2, fontface = "bold") +
  scale_fill_gradient2(low = "#D5F5E3", mid = "#F9E79F", high = "#E74C3C",
                       midpoint = 0.3, labels = percent_format()) +
  labs(title = "DPD Stage Migration Matrix",
       subtitle = "Transition rates between delinquency buckets",
       x = "To Bucket", y = "From Bucket", fill = "Transition Rate") +
  theme_risk() +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
ggsave("plots/RISK_01_StageMigration.png", p_migration, width = 10, height = 7, dpi = 150)

## 7.3  Portfolio at Risk (PAR) by Region
par_region <- loan %>%
  group_by(Region) %>%
  summarise(
    Total_Bal  = sum(CurrentBalance, na.rm = TRUE),
    DPD30_Bal  = sum(CurrentBalance[DelinquencyDays >= 30], na.rm = TRUE),
    PAR30_pct  = DPD30_Bal / Total_Bal * 100,
    DPD90_Bal  = sum(CurrentBalance[DelinquencyDays >= 90], na.rm = TRUE),
    PAR90_pct  = DPD90_Bal / Total_Bal * 100,
    .groups = "drop"
  )

p_par <- par_region %>%
  pivot_longer(c(PAR30_pct, PAR90_pct), names_to = "PAR", values_to = "Rate") %>%
  mutate(PAR = recode(PAR, "PAR30_pct" = "PAR 30+", "PAR90_pct" = "PAR 90+")) %>%
  ggplot(aes(x = reorder(Region, -Rate), y = Rate, fill = PAR)) +
  geom_col(position = "dodge", width = 0.6) +
  scale_fill_manual(values = c("PAR 30+" = "#F39C12", "PAR 90+" = "#E74C3C")) +
  scale_y_continuous(labels = function(x) paste0(x, "%")) +
  labs(title = "Portfolio at Risk (PAR) by Region",
       subtitle = "30+ and 90+ day delinquency as % of regional outstanding",
       x = NULL, y = "PAR (%)", fill = NULL) +
  theme_risk()
ggsave("plots/RISK_02_PAR_Region.png", p_par, width = 8, height = 5, dpi = 150)

## 7.4  Cure Rate & Roll Rate from DPD data
cure_summary <- dpd %>%
  filter(DPD_Bucket_Prior != "Current") %>%
  group_by(DPD_Bucket_Prior) %>%
  summarise(
    Total        = n(),
    Cured        = sum(CureFlag,  na.rm = TRUE),
    Rolled_Worse = sum(RollFlag == "Roll", na.rm = TRUE),
    Cure_Rate    = Cured / Total * 100,
    Roll_Rate    = Rolled_Worse / Total * 100,
    .groups = "drop"
  )
cat("\n  Cure Rate & Roll Rate by Prior DPD Bucket:\n")
print(cure_summary)

## 7.5  ECL trend visualisation
p_ecl_stage <- loan %>%
  group_by(IFRS9_Stage) %>%
  summarise(ECL_Cr = sum(ECL_Provision, na.rm = TRUE) / 1e7, .groups = "drop") %>%
  ggplot(aes(x = IFRS9_Stage, y = ECL_Cr, fill = IFRS9_Stage)) +
  geom_col(width = 0.5, show.legend = FALSE) +
  geom_text(aes(label = paste0("₹", round(ECL_Cr, 2), " Cr")),
            vjust = -0.4, fontface = "bold") +
  scale_fill_manual(values = c("Stage 1"="#27AE60","Stage 2"="#F39C12",
                                "Stage 3"="#E74C3C")) +
  labs(title = "Total ECL Provision by IFRS 9 Stage",
       subtitle = "Expected Credit Loss allocation across impairment stages",
       x = "IFRS 9 Stage", y = "ECL Provision (₹ Crore)") +
  theme_risk()
ggsave("plots/RISK_03_ECL_by_Stage.png", p_ecl_stage, width = 7, height = 5, dpi = 150)

## 7.6  Summary Executive KPI table
cat("\n\n  ====================================================\n")
cat("  EXECUTIVE SUMMARY — KEY PORTFOLIO METRICS\n")
cat("  ====================================================\n")
print(portfolio_kpis, n = Inf)

cat("\n\n  IFRS 9 ECL BREAKDOWN BY STAGE:\n")
print(ifrs9_summary)

cat("\n\n  CURE RATE SUMMARY:\n")
print(cure_summary)

cat("\n\n  ML MODEL COMPARISON:\n")
print(model_comparison)

cat("\n\n========================================\n")
cat("  ANALYSIS COMPLETE — All outputs saved.\n")
cat("  Plots directory: ./plots/\n")
cat("========================================\n")
